package com.example.restantapawbook.repository;

import com.example.restantapawbook.model.Queries;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QueryRepository extends JpaRepository<Queries, Long> {

}

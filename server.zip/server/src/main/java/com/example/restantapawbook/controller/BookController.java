package com.example.restantapawbook.controller;

import com.example.restantapawbook.model.Book;
import com.example.restantapawbook.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class BookController {//un controler REST care să primească cererile de căutare a cărților
    //si să returneze rezultatele sub forma unui răspuns JSON
    @Autowired
    private BookService bookService;

    @GetMapping("/book")
    List<Book> getBookByQuery(@RequestParam String query) {

        return bookService.findBooksByQuery(query);
    }

    @GetMapping("/books")
    List<Book> getAllBooks() {

        return bookService.getAllBooks();
    }
}

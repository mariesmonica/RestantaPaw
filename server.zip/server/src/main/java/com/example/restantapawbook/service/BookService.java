package com.example.restantapawbook.service;

import com.example.restantapawbook.model.Book;
import com.example.restantapawbook.model.Queries;
import com.example.restantapawbook.repository.BookRepository;
import com.example.restantapawbook.repository.QueryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private QueryRepository queryRepository;

    public List<Book> findBooksByQuery(String query){
        List<Book> books = bookRepository.searchBooks(query);
        if(books.size() == 0){
            Queries query1 = new Queries();
            query1.setQuery(query);
            queryRepository.save(query1);
        }
        return books;
    }

    public List<Book> getAllBooks( ){
        return bookRepository.findAll();
    }
}
